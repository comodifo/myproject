export { default } from './src/cell.vue';
