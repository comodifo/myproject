export { default } from './src/spinner';
